function c=centigrade(f)
c=(f-32)*5/9;