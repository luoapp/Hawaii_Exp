ws=input('enter problems subdir ','s');
eval(['cd ..\',ws]);
clear variables
close all
startup