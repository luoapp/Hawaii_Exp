function n=randint(L)
n=rand(size(L));
n=1+floor(n.*L);