function myfun
'hi'
