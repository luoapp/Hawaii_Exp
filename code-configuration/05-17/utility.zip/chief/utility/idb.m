function y=idb(x)
y=10.^(x*.05);