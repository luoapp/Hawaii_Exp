function y=flatten(x)
y=reshape(x,prod(size(x)),1);