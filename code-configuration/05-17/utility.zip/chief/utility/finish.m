%clean up unwanted files
disp('deleting computed_AB.mat')
pause(1)
!del computed_AB.mat